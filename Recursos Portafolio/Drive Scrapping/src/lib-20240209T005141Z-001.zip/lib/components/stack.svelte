<div class="r-stack">
	<slot />
</div>
