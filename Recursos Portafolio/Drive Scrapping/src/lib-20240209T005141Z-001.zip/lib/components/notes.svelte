<aside class="notes">
	<slot />
</aside>
