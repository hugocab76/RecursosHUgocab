import hljs from 'highlight.js'

export type Hljs = typeof hljs
