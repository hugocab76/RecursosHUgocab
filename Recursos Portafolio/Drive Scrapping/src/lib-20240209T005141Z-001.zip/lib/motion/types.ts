export type AnimationFn = () => Promise<void>
export type Resolve = (value?: any) => Promise<void>
