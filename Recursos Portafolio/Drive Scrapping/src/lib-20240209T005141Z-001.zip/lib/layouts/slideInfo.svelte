<div class="pt-5 absolute" style="top:50%;transform:translate(0,-50%)">
    <slot />
</div>