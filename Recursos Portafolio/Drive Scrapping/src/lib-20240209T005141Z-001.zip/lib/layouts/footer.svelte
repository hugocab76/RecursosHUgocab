<div class="font-thin text-sm text-right" style="position:absolute;bottom:0px;width:960px;border-top: solid 1px black">
    <p style="padding-top: 5px;"><b>Automatización de scrapping web con R y GitHub</b> | Adrián Maqueda</p>
    <p style="padding-top: 5px;"><i>R que R</i> – II Congreso de R | 15-17 de noviembre de 2023</p>
</div>