<script>
    export let title;
    export let subtitle;
</script>

<div class="absolute top-[0px]">
    <p class="font-bold text-5xl pb-3">{title}</p>
    <p class="text-2xl">{subtitle}</p>
</div>